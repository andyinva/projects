"""
Bible Search - Verse-Centric Bible Study Application.

A PyQt6-based application for searching, reading, and organizing Bible verses.

Modules:
    ui: User interface components
    core: Core search and data functionality (to be added)
    config: Configuration management (to be added)

Author: Andrew Hopkins
Email: ajhinva@gmail.com
"""

__version__ = '1.0.0'
__author__ = 'Andrew Hopkins'
