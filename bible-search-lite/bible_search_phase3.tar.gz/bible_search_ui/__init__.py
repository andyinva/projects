"""
Bible Search - Verse-Centric Bible Study Application.

A PyQt6-based application for searching, reading, and organizing Bible verses.

Modules:
    ui: User interface components (widgets, dialogs)
    config: Configuration management

Author: Andrew Hopkins
Email: ajhinva@gmail.com
"""

from .config import ConfigManager

__version__ = '1.0.0'
__author__ = 'Andrew Hopkins'
__all__ = ['ConfigManager']
